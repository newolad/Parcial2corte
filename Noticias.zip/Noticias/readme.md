# Como realice esta pagina Web ?


## 1. Archivo HTML (`index.html`)

Para la creación de esta página utilicé un tema que me apasiona muchísimo, el cual es el automovilísmo en competencia, para ser mas precisos la fórmula 1.

He utilizado la forma pedida por nuestro profesor, de la cual una parte nos ha explicado y algunos detalles lo he tenido que investigar.

En la estructura del "body" lo he dividido en cuatro partes "header", "nav", "main" y "footer" En los cuales he colocado la información necesaria organizada de una manera cómoda visualmente


## 2. Archivo CSS (`styles.css`)

En el archivo CSS he utilizado estilos sencillos pero que dan un toque diferente a la página creada, He incluido algunas imágenes descargadas de la red las cuales se expresan un mensaje muy relacionado al tema a tratar

Utilice la misma fuente para toda la página sin embargo especifique los tamaños en algunas secciones, también realicé cambios en los coloresde algunas fuentesel más notablees en la fuentedel encabezado ó header

En el área de navegación utilice un efecto de transformación de escala muy pequeña pero suficiente para resaltar el vínculo señalado, además al colocar el cursor sobre el enlace aparece la manita

En el área de noticias "tabla" marqué la zona de la tabla para una visión más ordenada, también adicioné un efecto de cambio de color en el fondo de las filas cuando el cursor pasa sobre ellas

Por último en el área de destacados "tarjetas O cards" apliqué un efecto sencillo pero que me pareció muy elegante el cual se trata de una transformación "scale 1.05" (que no me gusta) pero al incluir una transición de 0.3 segundos este efecto se visualiza mucho mejor

## 3. Conclusión

Cómo conclusión puedo decir qué la creación de esta página me ha parecido bastante divertida además he aprendido a utilizar mejor algunos efectos tanto de organización y alineación cómo de animaciones o efectos cuando los elementos son señalados y/o utilizados
